﻿using System; // Importing the System namespace for basic functionalities
using System.Collections.Generic; // Importing the System.Collections.Generic namespace for List
using System.Linq; // Importing the System.Linq namespace for LINQ queries

namespace RecipeApp
{
    public delegate string caloryDelegate(double calory);
    enum FoodGroup // Declaring an enum representing food groups
    {
        Fruits,
        Vegetables,
        Grains,
        Protein,
        Dairy,
        Fats_Oils,
        Sugars_Sweets
    }

    class Ingredient // Defining a class to represent an ingredient
    {
        public string Name { get; set; } // Property for the name of the ingredient
        public double Quantity { get; set; } // Property for the quantity of the ingredient
        public string Unit { get; set; } // Property for the unit of measurement for the ingredient
        public double Calories { get; set; } // Property for the number of calories for the ingredient
        public FoodGroup Group { get; set; } // Property for the food group of the ingredient
    }

    class Recipe // Defining a class to represent a recipe
    {
        public string Name { get; set; } // Property for the name of the recipe
        public List<Ingredient> Ingredients { get; set; } // Property for the list of ingredients in the recipe
        public List<string> Steps { get; set; } // Property for the list of steps to prepare the recipe

        // Method to enter recipe details
        public void EnterDetails()
        {
            Console.Write("\nEnter recipe name: "); // Prompting user to enter the recipe name
            Name = Console.ReadLine(); // Reading the recipe name from the console

            Ingredients = new List<Ingredient>(); // Initializing list of ingredients
            Steps = new List<string>(); // Initializing list of steps

            Console.Write("\nEnter number of ingredients: "); // Prompting user to enter the number of ingredients
            int ingredientCount = int.Parse(Console.ReadLine()); // Reading the number of ingredients from the console

            for (int i = 0; i < ingredientCount; i++) // Loop for entering ingredient details
            {
                Ingredient ingredient = new Ingredient(); // Creating a new ingredient object

                Console.Write($"Enter name of ingredient {i + 1}: "); // Prompting user to enter the name of the ingredient
                ingredient.Name = Console.ReadLine(); // Reading the name of the ingredient from the console

                Console.Write($"Enter quantity of {ingredient.Name}: "); // Prompting user to enter the quantity of the ingredient
                ingredient.Quantity = double.Parse(Console.ReadLine()); // Reading the quantity of the ingredient from the console

                Console.Write($"Enter unit of measurement for {ingredient.Name}: "); // Prompting user to enter the unit of measurement for the ingredient
                ingredient.Unit = Console.ReadLine(); // Reading the unit of measurement from the console

                Console.Write($"Enter number of calories for {ingredient.Name}: "); // Prompting user to enter the number of calories for the ingredient
                ingredient.Calories = double.Parse(Console.ReadLine()); // Reading the number of calories from the console

                bool validFoodGroup = false;
                while (!validFoodGroup) // Loop until a valid food group is entered
                {
                    try
                    {
                        Console.Write($"Enter food group for {ingredient.Name} (Fruits, Vegetables, Grains, Protein, Dairy, Fats_Oils, Sugars_Sweets): "); // Prompting user to enter the food group
                        ingredient.Group = (FoodGroup)Enum.Parse(typeof(FoodGroup), Console.ReadLine(), true); // Parsing and setting the food group
                        validFoodGroup = true; // Setting validFoodGroup to true if parsing succeeds
                    }
                    catch (ArgumentException)
                    {
                        Console.WriteLine("Invalid food group. Please enter a valid food group."); // Error message for invalid food group
                    }
                }

                Ingredients.Add(ingredient); // Adding ingredient to the list
            }

            Console.Write("\nEnter number of steps: "); // Prompting user to enter the number of steps
            int stepCount = int.Parse(Console.ReadLine()); // Reading the number of steps from the console

            for (int i = 0; i < stepCount; i++) // Loop for entering step details
            {
                Console.Write($"Enter step {i + 1} description: "); // Prompting user to enter the step description
                Steps.Add(Console.ReadLine()); // Reading and adding step description to the list
            }

            Console.WriteLine("Recipe details entered successfully!"); // Confirmation message
        }

        // Method to display recipe details
        public void Display()
        {
            RecipeManager recipeManager = new RecipeManager();
            caloryDelegate caloryDelegate = recipeManager.caloryMethod;
            Console.WriteLine($"\nRecipe Name: {Name}"); // Displaying the name of the recipe
            double count = 0;
            Console.WriteLine("\nIngredients:"); // Displaying the list of ingredients
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"- {ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories)");
                count += ingredient.Quantity;

                // Displaying each ingredient
            }
            Console.WriteLine(caloryDelegate.Invoke(count));

            Console.WriteLine("\nSteps:"); // Displaying the list of steps
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}"); // Displaying each step
            }
        }

        // Method to calculate total calories of the recipe
        public double CalculateTotalCalories()
        {
            return Ingredients.Sum(ingredient => ingredient.Calories); // Summing up calories from all ingredients
        }

        // Method to scale the recipe
        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor; // Scaling the quantity of each ingredient
            }
            Console.WriteLine("The recipe is scaled successfully!"); // Confirmation message
        }

        // Method to reset quantities of all ingredients in the recipe
        public void ResetQuantities()
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity = 0; // Resetting the quantity of each ingredient to 0
            }
            Console.WriteLine("Quantities reset successfully!"); // Confirmation message
        }
    }

    class RecipeManager // Defining a class to manage recipes
    {
        private List<Recipe> recipes = new List<Recipe>(); // List to store recipes

        public int RecipesCount => recipes.Count; // Property to get the number of recipes

        // Method to enter recipe details
        public void EnterRecipeDetails()
        {
            Recipe recipe = new Recipe(); // Creating a new recipe object
            recipe.EnterDetails(); // Calling the method to enter recipe details
            recipes.Add(recipe); // Adding the recipe to the list


        }
        public string caloryMethod(double calory)
        {
            string warning = "";
            if (calory >= 300)
            {
                warning = "Warning: This recipe exceeds 300 calories!";
            }
            return warning;
        }
        // Method to display recipes
        public void DisplayRecipes()
        {
            if (recipes.Count == 0) // Checking if there are no recipes available
            {
                Console.WriteLine("No recipes available."); // Message for no recipes available
                return;
            }

            Console.WriteLine("\nList of Recipes (sorted by name):"); // Displaying the list of recipes
            recipes = recipes.OrderBy(r => r.Name).ToList(); // Sorting recipes by name

            foreach (var recipe in recipes)
            {
                Console.WriteLine($"- {recipe.Name}"); // Displaying each recipe
            }

            Console.Write("\nEnter the name of the recipe to display details: "); // Prompting user to enter the name of the recipe
            string recipeName = Console.ReadLine(); // Reading the name of the recipe from the console

            Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase)); // Finding the selected recipe

            if (selectedRecipe != null) // If the recipe is found
            {
                selectedRecipe.Display(); // Displaying recipe details
            }
            else
            {
                Console.WriteLine("Recipe not found."); // Message for recipe not found
            }
        }

        // Method to scale a recipe
        public void ScaleRecipe()
        {
            if (recipes.Count == 0) // Checking if there are no recipes available
            {
                Console.WriteLine("No recipes available to scale."); // Message for no recipes available to scale
                return;
            }

            Console.WriteLine("\nList of Recipes (sorted by name):"); // Displaying the list of recipes
            recipes = recipes.OrderBy(r => r.Name).ToList(); // Sorting recipes by name

            foreach (var recipe in recipes)
            {
                Console.WriteLine($"- {recipe.Name}"); // Displaying each recipe
            }

            Console.Write("\nEnter the name of the recipe to scale: "); // Prompting user to enter the name of the recipe to scale
            string recipeName = Console.ReadLine(); // Reading the name of the recipe from the console

            Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase)); // Finding the selected recipe

            if (selectedRecipe != null) // If the recipe is found
            {
                double factor;
                while (true) // Loop for input validation
                {
                    Console.Write("\nPlese enter scaling factor (0.5, 2, or 3): "); // Prompting user to enter the scaling factor
                    if (double.TryParse(Console.ReadLine(), out factor) && (factor == 0.5 || factor == 2 || factor == 3)) // Validating the input
                    {
                        selectedRecipe.ScaleRecipe(factor); // Scaling the recipe
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid scaling factor. Please enter 0.5, 2, or 3."); // Error message for invalid scaling factor
                    }
                }
            }
            else
            {
                Console.WriteLine("Recipe not found."); // Message for recipe not found
            }
        }

        // Method to reset quantities of a recipe
        public void ResetQuantities()
        {
            if (recipes.Count == 0) // Checking if there are no recipes available
            {
                Console.WriteLine("No recipes available to reset quantities."); // Message for no recipes available to reset quantities
                return;
            }

            Console.WriteLine("\nList of Recipes (sorted by name):"); // Displaying the list of recipes
            recipes = recipes.OrderBy(r => r.Name).ToList(); // Sorting recipes by name

            foreach (var recipe in recipes)
            {
                Console.WriteLine($"- {recipe.Name}"); // Displaying each recipe
            }

            Console.Write("\nEnter the name of the recipe to reset quantities: "); // Prompting user to enter the name of the recipe to reset quantities
            string recipeName = Console.ReadLine(); // Reading the name of the recipe from the console

            Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase)); // Finding the selected recipe

            if (selectedRecipe != null) // If the recipe is found
            {
                selectedRecipe.ResetQuantities(); // Resetting the quantities of the ingredients in the recipe
            }
            else
            {
                Console.WriteLine("Recipe not found."); // Message for recipe not found
            }
        }

        // Method to clear all recipe data
        public void ClearData()
        {
            recipes.Clear(); // Clearing the list of recipes
            Console.WriteLine("All data cleared."); // Confirmation message
        }
    }

    class Program // Main class
    {
        static void Main(string[] args) // Main method
        {
            RecipeManager recipeManager = new RecipeManager(); // Creating an instance of RecipeManager

            Console.WriteLine("WELCOME TO THE   CHEIFS RECIPE APP"); // Welcome message

            while (true) // Main menu loop
            {
                Console.WriteLine("\nMenu:"); // Displaying the menu options
                Console.WriteLine("1. Please enter recipe details");
                Console.WriteLine("2. Then display recipes");
                Console.WriteLine("3. Then scale recipe");
                Console.WriteLine("4. Then reset quantities");
                Console.WriteLine("5. Then clear all data");
                Console.WriteLine("6. Then exit");

                try // Handling user input
                {
                    Console.Write("\nPlease enter your choice: "); // Prompting user to enter a choice
                    int choice = int.Parse(Console.ReadLine()); // Reading the choice from the console

                    switch (choice) // Switching based on user choice
                    {
                        case 1:
                            recipeManager.EnterRecipeDetails(); // Invoking method to enter recipe details
                            break;
                        case 2:
                            recipeManager.DisplayRecipes(); // Invoking method to display recipes
                            break;
                        case 3:
                            recipeManager.ScaleRecipe(); // Invoking method to scale recipe
                            break;
                        case 4:
                            recipeManager.ResetQuantities(); // Invoking method to reset quantities
                            break;
                        case 5:
                            recipeManager.ClearData(); // Invoking method to clear all data
                            break;
                        case 6:
                            Console.WriteLine("Exiting the Recipe App. Goodbye!"); // Exiting the program
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Invalid choice. Please enter a number between 1 and 6."); // Error message for invalid choice
                            break;
                    }
                }
                catch (FormatException) // Handling invalid input format
                {
                    Console.WriteLine("Invalid input. Please enter a valid number."); // Error message for invalid input format
                }
                catch (ArgumentException ex) // Handling argument-related exceptions
                {
                    Console.WriteLine(ex.Message); // Displaying the exception message
                }
                catch (InvalidOperationException ex) // Handling invalid operation exceptions
                {
                    Console.WriteLine(ex.Message); // Displaying the exception message
                }
            }
        }
    }
}
